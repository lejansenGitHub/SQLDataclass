#!/usr/bin/env python3
"""
Repository classes must extend ReadRepository or WriteRepository.
Classes with 'Repository' in the name must inherit from the base classes.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files

BASE_CLASSES = {"ReadRepository", "WriteRepository"}


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    errors: list[str] = []
    # Skip the base repository module itself
    if filepath.name == "repository.py" and "base" in filepath.parts and "db" in filepath.parts:
        return errors

    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        if "Repository" not in node.name:
            continue

        base_names: set[str] = set()
        for base in node.bases:
            if isinstance(base, ast.Name):
                base_names.add(base.id)
            elif isinstance(base, ast.Attribute):
                base_names.add(base.attr)

        if not base_names & BASE_CLASSES:
            # Check if any base might be a subclass (indirect inheritance)
            # We can only check direct names statically
            has_repository_base = any("Repository" in name for name in base_names)
            if not has_repository_base:
                errors.append(
                    f"{filepath}:{node.lineno}: "
                    f"Repository class {node.name} does not extend ReadRepository or WriteRepository."
                )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "enforce repository base class"))


if __name__ == "__main__":
    main()
