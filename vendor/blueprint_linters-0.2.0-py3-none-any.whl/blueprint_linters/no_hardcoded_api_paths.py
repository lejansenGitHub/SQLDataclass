#!/usr/bin/env python3
"""
API paths must use constants from urls.py, not hardcoded strings.

Rejects string literals starting with "/api/" in backend code.
Exemptions: urls.py itself, and non-backend files.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """Reject hardcoded /api/ path strings in backend code."""
    errors: list[str] = []

    if not str(filepath).startswith("backend"):
        return errors
    if filepath.name == "urls.py":
        return errors

    for node in ast.walk(tree):
        if not isinstance(node, ast.Constant) or not isinstance(node.value, str):
            continue
        value = node.value
        if value.startswith("/api/"):
            errors.append(
                f"{filepath}:{node.lineno}: "
                f"Hardcoded API path '{value}'. Use constants from backend.app.api.src.urls instead."
            )

    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no hardcoded API paths"))


if __name__ == "__main__":
    main()
