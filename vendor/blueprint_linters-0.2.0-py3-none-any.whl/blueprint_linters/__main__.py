"""Allow running via `python -m blueprint_linters --preset webapp [files...]`."""

from blueprint_linters.run import main

main()
