#!/usr/bin/env python3
"""
Enforce backend layer import direction: base <- service <- app.

- base/ may not import from service/ or app/
- service/ may not import from app/
- app/ may import from service/ and base/
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files

LAYER_ORDER = {"base": 0, "service": 1, "app": 2}


def _get_file_layer(filepath: Path) -> str | None:
    """
    Determine which layer a file belongs to.
    """
    parts = filepath.parts
    try:
        backend_idx = parts.index("backend")
    except ValueError:
        return None
    if backend_idx + 1 < len(parts):
        layer = parts[backend_idx + 1]
        if layer in LAYER_ORDER:
            return layer
    return None


def _get_import_layer(import_path: str) -> str | None:
    """
    Extract the layer from an import path like 'backend.service.orders.src.repo'.
    """
    parts = import_path.split(".")
    if len(parts) >= 2 and parts[0] == "backend":
        layer = parts[1]
        if layer in LAYER_ORDER:
            return layer
    return None


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """
    Reject imports that violate the layer hierarchy.
    """
    errors: list[str] = []
    file_layer = _get_file_layer(filepath)
    if file_layer is None:
        return errors

    file_rank = LAYER_ORDER[file_layer]

    for node in ast.walk(tree):
        import_paths: list[str] = []

        if isinstance(node, ast.ImportFrom) and node.module is not None:
            import_paths.append(node.module)
        elif isinstance(node, ast.Import):
            import_paths.extend(alias.name for alias in node.names)

        for import_path in import_paths:
            import_layer = _get_import_layer(import_path)
            if import_layer is None:
                continue
            import_rank = LAYER_ORDER[import_layer]
            if import_rank > file_rank:
                errors.append(
                    f"{filepath}:{node.lineno}: "
                    f"Layer violation: {file_layer}/ cannot import from {import_layer}/. "
                    f"Import direction must be base <- service <- app."
                )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "enforce layer imports"))


if __name__ == "__main__":
    main()
