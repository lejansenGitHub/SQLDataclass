#!/usr/bin/env python3
"""
No exports/ imports inside src/.
src/ must not import from its own module's exports/ to avoid cycles.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def _is_in_src(filepath: Path) -> bool:
    return "src" in filepath.parts


def _get_module_prefix(filepath: Path) -> str | None:
    """
    Extract module import prefix from file path.
    backend/service/orders/src/repo.py -> "backend.service.orders"
    """
    parts = filepath.parts
    try:
        src_idx = parts.index("src")
    except ValueError:
        return None
    try:
        backend_idx = parts.index("backend")
    except ValueError:
        return None
    module_parts = parts[backend_idx:src_idx]
    return ".".join(module_parts)


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    errors: list[str] = []
    if not _is_in_src(filepath):
        return errors

    module_prefix = _get_module_prefix(filepath)
    if module_prefix is None:
        return errors

    exports_prefix = f"{module_prefix}.exports"

    for node in ast.walk(tree):
        import_paths: list[str] = []

        if isinstance(node, ast.ImportFrom) and node.module is not None:
            import_paths.append(node.module)
        elif isinstance(node, ast.Import):
            import_paths.extend(alias.name for alias in node.names)

        for import_path in import_paths:
            if import_path.startswith(exports_prefix):
                errors.append(
                    f"{filepath}:{node.lineno}: "
                    f"src/ imports from own exports/: {import_path}. "
                    f"Define in src/ and re-export from exports/ — not the other way around."
                )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no export import in src"))


if __name__ == "__main__":
    main()
