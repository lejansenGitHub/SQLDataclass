#!/usr/bin/env python3
"""
Prevent raising bare HTTP errors (HTTPException, etc.) outside test files.

All business errors must be domain exceptions from base/exceptions/.
The global FastAPI error handler translates them to HTTP responses.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files

_BANNED_NAMES = {"HTTPException", "StarletteHTTPException", "WebSocketException"}


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """
    Reject raising HTTP framework exceptions in non-test backend code.
    """
    errors: list[str] = []

    if "tests" in filepath.parts:
        return errors
    if not str(filepath).startswith("backend"):
        return errors

    for node in ast.walk(tree):
        if not isinstance(node, ast.Raise) or node.exc is None:
            continue

        call_node = node.exc
        func = call_node.func if isinstance(call_node, ast.Call) else call_node

        name = None
        if isinstance(func, ast.Name):
            name = func.id
        elif isinstance(func, ast.Attribute):
            name = func.attr

        if name in _BANNED_NAMES:
            errors.append(
                f"{filepath}:{node.lineno}: "
                f"raise {name}() is banned. Use domain exceptions from "
                f"backend.base.exceptions.src.domain instead."
            )

    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no bare HTTP errors"))


if __name__ == "__main__":
    main()
