#!/usr/bin/env python3
"""
Files in exports/types/ may only contain type definitions and re-exports.
No function bodies, no method implementations — only classes, type aliases, and imports.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def _is_types_export(filepath: Path) -> bool:
    parts = filepath.parts
    try:
        types_idx = parts.index("types")
        return types_idx > 0 and parts[types_idx - 1] == "exports"
    except ValueError:
        return False


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    errors: list[str] = []
    if not _is_types_export(filepath):
        return errors
    if filepath.name == "__init__.py":
        return errors

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            errors.append(
                f"{filepath}:{node.lineno}: "
                f"Function definition in exports/types/: {node.name}. "
                f"Type export files may only contain classes, type aliases, and imports."
            )
        elif isinstance(node, ast.ClassDef):
            for class_node in ast.iter_child_nodes(node):
                if isinstance(class_node, ast.FunctionDef | ast.AsyncFunctionDef):
                    # Allow methods that are just `...` or `pass` (abstract/protocol stubs)
                    body = class_node.body
                    is_stub = len(body) == 1 and (
                        isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and body[0].value.value is ...
                        or isinstance(body[0], ast.Pass)
                    )
                    if not is_stub:
                        errors.append(
                            f"{filepath}:{class_node.lineno}: "
                            f"Method with implementation in exports/types/: {node.name}.{class_node.name}. "
                            f"Type export classes may only have stub methods (... or pass)."
                        )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "types-only exports"))


if __name__ == "__main__":
    main()
