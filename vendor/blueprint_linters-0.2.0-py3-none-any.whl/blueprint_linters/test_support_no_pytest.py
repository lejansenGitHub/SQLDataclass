#!/usr/bin/env python3
"""
No pytest import in factory, case, and mock files.
Only *_fixtures.py files may depend on pytest.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files

PLAIN_SUFFIXES = ("_factory.py", "_cases.py", "_mock.py")


def _is_plain_test_support(filepath: Path) -> bool:
    return any(filepath.name.endswith(suffix) for suffix in PLAIN_SUFFIXES)


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    errors: list[str] = []
    if not _is_plain_test_support(filepath):
        return errors

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "pytest" or alias.name.startswith("pytest."):
                    errors.append(
                        f"{filepath}:{node.lineno}: "
                        f"pytest import in {filepath.name}. "
                        f"Factory/case/mock files must be plain Python. "
                        f"Move pytest-dependent code to a *_fixtures.py file."
                    )
        elif isinstance(node, ast.ImportFrom) and node.module is not None:
            if node.module == "pytest" or node.module.startswith("pytest."):
                errors.append(
                    f"{filepath}:{node.lineno}: "
                    f"pytest import in {filepath.name}. "
                    f"Factory/case/mock files must be plain Python. "
                    f"Move pytest-dependent code to a *_fixtures.py file."
                )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no pytest in factory/case/mock files"))


if __name__ == "__main__":
    main()
