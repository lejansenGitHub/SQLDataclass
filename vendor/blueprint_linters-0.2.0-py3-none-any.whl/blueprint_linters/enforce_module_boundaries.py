#!/usr/bin/env python3
"""
Enforce that src/ folders are not imported by other modules.
A module's src/ is private — only its own code may import from it.
"""

from __future__ import annotations

import ast
import re
import sys
from pathlib import Path

from blueprint_linters.common import check_files

SRC_IMPORT_PATTERN = re.compile(r"backend\.(\w+)\.(\w+)\.src")


def _get_module_path(filepath: Path) -> tuple[str, str, str] | None:
    """
    Extract (layer, module_name) from a file path like
    backend/service/orders/src/repo.py -> ("service", "orders")
    """
    parts = filepath.parts
    try:
        backend_idx = parts.index("backend")
    except ValueError:
        return None
    remaining = parts[backend_idx + 1 :]
    if len(remaining) >= 2:
        return ("backend", remaining[0], remaining[1])
    return None


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """
    Reject imports from another module's src/ folder.
    """
    errors: list[str] = []
    own_module = _get_module_path(filepath)

    for node in ast.walk(tree):
        import_path: str | None = None

        if isinstance(node, ast.ImportFrom) and node.module is not None:
            import_path = node.module
        elif isinstance(node, ast.Import):
            for alias in node.names:
                match = SRC_IMPORT_PATTERN.search(alias.name)
                if match:
                    imported_layer = match.group(1)
                    imported_module_name = match.group(2)
                    if own_module is None or (imported_layer, imported_module_name) != (own_module[1], own_module[2]):
                        errors.append(
                            f"{filepath}:{node.lineno}: "
                            f"Import from another module's src/: {alias.name}. "
                            f"Use exports/ instead."
                        )
            continue

        if import_path is None:
            continue

        match = SRC_IMPORT_PATTERN.search(import_path)
        if match:
            imported_layer = match.group(1)
            imported_module = match.group(2)
            if own_module is None or (imported_layer, imported_module) != (own_module[1], own_module[2]):
                errors.append(
                    f"{filepath}:{node.lineno}: "
                    f"Import from another module's src/: {import_path}. "
                    f"Use exports/ instead."
                )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "enforce module boundaries"))


if __name__ == "__main__":
    main()
