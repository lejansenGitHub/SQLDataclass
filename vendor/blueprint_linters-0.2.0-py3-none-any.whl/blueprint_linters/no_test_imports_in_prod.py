#!/usr/bin/env python3
"""
Production code must not import from .tests (including test_support/).
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def _is_test_file(filepath: Path) -> bool:
    return "tests" in filepath.parts


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    errors: list[str] = []
    if _is_test_file(filepath):
        return errors

    for node in ast.walk(tree):
        import_paths: list[str] = []

        if isinstance(node, ast.ImportFrom) and node.module is not None:
            import_paths.append(node.module)
        elif isinstance(node, ast.Import):
            import_paths.extend(alias.name for alias in node.names)

        for import_path in import_paths:
            if ".tests." in import_path or import_path.endswith(".tests"):
                errors.append(
                    f"{filepath}:{node.lineno}: "
                    f"Production code imports from .tests: {import_path}. "
                    f"Test utilities must not leak into production code."
                )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no test imports in production"))


if __name__ == "__main__":
    main()
