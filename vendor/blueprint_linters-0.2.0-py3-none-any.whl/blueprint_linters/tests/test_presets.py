"""Tests for preset configurations and the combined runner."""

from __future__ import annotations

from blueprint_linters.presets import LIB_CROSS_FILE, LIB_PER_FILE, PRESETS, WEBAPP_CROSS_FILE, WEBAPP_PER_FILE


def test_webapp_preset_has_all_categories() -> None:
    """
    Webapp preset should include per-file linters, cross-file linters,
    and at least 10 total linters (sanity check against accidental removal).
    """
    per_file, cross_file = PRESETS["webapp"]
    assert len(per_file) >= 10
    assert len(cross_file) >= 2


def test_lib_preset_is_subset_of_webapp() -> None:
    """
    Every lib linter should also appear in the webapp preset — lib is a
    strict subset (fewer rules, not different rules).
    """
    webapp_modules = {spec.module_name for spec in WEBAPP_PER_FILE + WEBAPP_CROSS_FILE}
    lib_modules = {spec.module_name for spec in LIB_PER_FILE + LIB_CROSS_FILE}
    extra = lib_modules - webapp_modules
    assert extra == set(), f"Lib preset has linters not in webapp: {extra}"


def test_lib_preset_has_no_cross_file() -> None:
    """
    Lib preset should have no cross-file linters (no endpoints to check).
    """
    assert LIB_CROSS_FILE == []


def test_webapp_cross_file_linters_are_marked() -> None:
    """
    All cross-file linters must have cross_file=True.
    """
    for spec in WEBAPP_CROSS_FILE:
        assert spec.cross_file is True, f"{spec.module_name} should be cross_file=True"


def test_per_file_linters_are_not_cross_file() -> None:
    """
    Per-file linters must not have cross_file=True.
    """
    for spec in WEBAPP_PER_FILE + LIB_PER_FILE:
        assert spec.cross_file is False, f"{spec.module_name} should be cross_file=False"


def test_linter_spec_matches_file() -> None:
    """
    LinterSpec.matches_file should filter correctly based on patterns.
    """
    from blueprint_linters.presets import LinterSpec

    spec = LinterSpec("test", files_pattern=r"^backend/.*tests/", exclude_pattern=r"conftest\.py$")
    assert spec.matches_file("backend/service/orders/tests/test_order.py") is True
    assert spec.matches_file("backend/service/orders/tests/conftest.py") is False
    assert spec.matches_file("frontend/tests/test_app.py") is False


def test_all_linter_modules_importable() -> None:
    """
    Every module referenced in presets must be importable.
    """
    import importlib

    all_specs = WEBAPP_PER_FILE + WEBAPP_CROSS_FILE + LIB_PER_FILE + LIB_CROSS_FILE
    seen = set()
    for spec in all_specs:
        if spec.module_name in seen:
            continue
        seen.add(spec.module_name)
        try:
            importlib.import_module(f"blueprint_linters.{spec.module_name}")
        except ImportError as error:
            raise AssertionError(f"Cannot import blueprint_linters.{spec.module_name}") from error
