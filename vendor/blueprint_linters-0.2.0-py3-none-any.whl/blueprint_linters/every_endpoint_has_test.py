#!/usr/bin/env python3
"""
Every endpoint URL constant used in a @router decorator must be referenced in at least one test file.

Scans *_endpoints.py files for @router.get/post/patch/delete(URL_CONSTANT) patterns
and verifies each URL constant appears in at least one test file import.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path


def _collect_endpoint_url_constants(backend_path: Path) -> dict[str, str]:
    """
    Find all URL constants used in @router.get/post/patch/delete() decorators.
    Returns {constant_name: filepath_and_line} for each endpoint.
    """
    endpoint_urls: dict[str, str] = {}

    for filepath in backend_path.rglob("*_endpoints.py"):
        try:
            source = filepath.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(filepath))
        except SyntaxError:
            continue

        for node in ast.walk(tree):
            if not isinstance(node, ast.FunctionDef):
                continue
            for decorator in node.decorator_list:
                if not isinstance(decorator, ast.Call):
                    continue
                func = decorator.func
                if not isinstance(func, ast.Attribute):
                    continue
                if func.attr not in ("get", "post", "patch", "delete", "put"):
                    continue
                if not decorator.args:
                    continue
                first_arg = decorator.args[0]
                if isinstance(first_arg, ast.Name):
                    endpoint_urls[first_arg.id] = f"{filepath}:{node.lineno}"

    return endpoint_urls


def _collect_test_url_imports(test_path: Path) -> set[str]:
    """
    Find all URL constants imported in test files from urls module.
    """
    imported_names: set[str] = set()

    for filepath in test_path.rglob("test_*.py"):
        try:
            source = filepath.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(filepath))
        except SyntaxError:
            continue

        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module and "urls" in node.module:
                for alias in node.names:
                    imported_names.add(alias.name)

    return imported_names


def check_all(backend_path: Path) -> list[str]:
    """
    Check that every endpoint URL constant is referenced in at least one test file.
    Returns list of error messages.
    """
    endpoint_urls = _collect_endpoint_url_constants(backend_path)
    test_imports = _collect_test_url_imports(backend_path)

    errors: list[str] = []
    for constant_name, location in sorted(endpoint_urls.items()):
        if constant_name not in test_imports:
            errors.append(f"{location}: Endpoint using {constant_name} has no test (not imported in any test file)")

    return errors


def main() -> None:
    backend = Path("backend")
    if len(sys.argv) > 1:
        # When called by pre-commit with file paths, still scan the whole backend
        # (this linter is cross-file, not per-file)
        pass
    errors = check_all(backend)
    for error in errors:
        print(error)  # noqa: T201  # linter output
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
