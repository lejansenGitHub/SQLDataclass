#!/usr/bin/env python3
"""
Mock hygiene linter — two rules:

1. MagicMock() must always use spec= for type safety.
   Without spec, typos in attribute names silently pass.

2. Test functions must not use the monkeypatch fixture.
   Use mocker.patch() from pytest-mock instead.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def _is_magicmock_call(node: ast.Call) -> bool:
    """
    Check if a Call node is MagicMock() or *.MagicMock().
    """
    if isinstance(node.func, ast.Name) and node.func.id == "MagicMock":
        return True
    if isinstance(node.func, ast.Attribute) and node.func.attr == "MagicMock":
        return True
    return False


def _has_spec_kwarg(node: ast.Call) -> bool:
    return any(kw.arg == "spec" for kw in node.keywords)


def _uses_monkeypatch_fixture(node: ast.FunctionDef) -> int | None:
    """Return the line number if the function has a 'monkeypatch' parameter."""
    for arg in node.args.args:
        if arg.arg == "monkeypatch":
            return arg.lineno
    return None


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    errors: list[str] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and _is_magicmock_call(node) and not _has_spec_kwarg(node):
            errors.append(
                f"{filepath}:{node.lineno}: "
                f"MagicMock() without spec=. "
                f"Always use MagicMock(spec=TargetClass) for type safety."
            )
        if isinstance(node, ast.FunctionDef):
            lineno = _uses_monkeypatch_fixture(node)
            if lineno is not None:
                errors.append(
                    f"{filepath}:{lineno}: "
                    f"monkeypatch fixture in {node.name}(). "
                    f"Use mocker.patch() from pytest-mock instead."
                )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "MagicMock requires spec"))


if __name__ == "__main__":
    main()
