#!/usr/bin/env python3
"""
Exports must be minimal — every symbol in exports/ must be imported by at least
one other module.

Scans all exports/ directories for defined symbols (classes, functions, type aliases),
then checks that each symbol is imported somewhere outside its own module.
Dead exports increase coupling surface without providing value.
"""

from __future__ import annotations

import ast
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ExportedSymbol:
    module_path: str  # e.g. "backend.service.orders"
    filepath: Path
    name: str
    lineno: int


def _get_module_prefix(filepath: Path) -> str | None:
    """Extract module prefix from path: backend/service/orders/exports/... → backend.service.orders."""
    parts = filepath.parts
    try:
        exports_idx = parts.index("exports")
    except ValueError:
        return None
    return ".".join(parts[:exports_idx])


def _collect_exported_symbols(backend_path: Path) -> list[ExportedSymbol]:
    """Find all symbols defined in exports/ directories."""
    symbols: list[ExportedSymbol] = []

    for exports_dir in backend_path.rglob("exports"):
        if not exports_dir.is_dir():
            continue

        for py_file in exports_dir.rglob("*.py"):
            if py_file.name == "__init__.py":
                continue

            module_prefix = _get_module_prefix(py_file)
            if module_prefix is None:
                continue

            try:
                source = py_file.read_text(encoding="utf-8")
                tree = ast.parse(source, filename=str(py_file))
            except SyntaxError:
                continue

            for node in ast.iter_child_nodes(tree):
                if isinstance(node, ast.ClassDef):
                    symbols.append(ExportedSymbol(module_prefix, py_file, node.name, node.lineno))
                elif isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                    symbols.append(ExportedSymbol(module_prefix, py_file, node.name, node.lineno))
                elif isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and not target.id.startswith("_"):
                            symbols.append(ExportedSymbol(module_prefix, py_file, target.id, node.lineno))
                elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
                    if not node.target.id.startswith("_"):
                        symbols.append(ExportedSymbol(module_prefix, py_file, node.target.id, node.lineno))

    return symbols


def _collect_all_imports(backend_path: Path) -> set[str]:
    """Collect all imported names across the entire backend."""
    imported_names: set[str] = set()

    for py_file in backend_path.rglob("*.py"):
        try:
            source = py_file.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(py_file))
        except SyntaxError:
            continue

        file_module_prefix = _get_module_prefix(py_file)

        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                # Only count imports from exports/ directories
                if "exports" in node.module:
                    for alias in node.names:
                        # Don't count self-imports (same module importing its own export)
                        importing_prefix = ".".join(str(py_file).split("/")[:3]) if "/" in str(py_file) else ""
                        imported_names.add(alias.name)

    return imported_names


def check_all(backend_path: Path) -> list[str]:
    """Check that every exported symbol is imported by at least one consumer."""
    if not backend_path.exists():
        return []

    exported = _collect_exported_symbols(backend_path)
    if not exported:
        return []

    all_imports = _collect_all_imports(backend_path)

    errors: list[str] = []
    for symbol in sorted(exported, key=lambda s: (str(s.filepath), s.lineno)):
        if symbol.name not in all_imports:
            errors.append(
                f"{symbol.filepath}:{symbol.lineno}: Exported symbol '{symbol.name}' "
                f"is not imported by any other module — consider removing it from exports/"
            )

    return errors


def main() -> None:
    backend = Path("backend")
    if len(sys.argv) > 1:
        backend = Path(sys.argv[1])
    errors = check_all(backend)
    for error in errors:
        print(error)  # noqa: T201  # linter diagnostic output
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
