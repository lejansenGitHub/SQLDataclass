"""
Combined linter runner for pre-commit presets.

Usage:
  python -m blueprint_linters.run --preset webapp [files...]     # per-file linters
  python -m blueprint_linters.run --preset webapp --push-only    # cross-file linters (pre-push)

Consumers add two hooks to .pre-commit-config.yaml:

  - id: blueprint-linters
    entry: python -m blueprint_linters.run --preset webapp
    language: system
    types: [python]

  - id: blueprint-linters-push
    entry: python -m blueprint_linters.run --preset webapp --push-only
    language: system
    pass_filenames: false
    stages: [pre-push]
    always_run: true
"""

from __future__ import annotations

import ast
import importlib
import sys
from pathlib import Path

from blueprint_linters.presets import PRESETS, LinterSpec


def _run_per_file_linter(spec: LinterSpec, filepaths: list[str]) -> list[str]:
    """Run a per-file linter on matching files."""
    module = importlib.import_module(f"blueprint_linters.{spec.module_name}")
    check_file = getattr(module, "check_file", None)
    if check_file is None:
        return []

    import inspect
    takes_tree = len(inspect.signature(check_file).parameters) >= 2

    errors: list[str] = []
    for filepath_str in filepaths:
        if not spec.matches_file(filepath_str):
            continue
        filepath = Path(filepath_str)
        if not filepath.exists() or filepath.suffix != ".py":
            continue

        if takes_tree:
            try:
                source = filepath.read_text(encoding="utf-8")
                tree = ast.parse(source, filename=filepath_str)
            except SyntaxError:
                continue
            file_errors = check_file(filepath, tree)
        else:
            file_errors = check_file(filepath)
        errors.extend(file_errors)

    return errors


_LINTER_PATHS: dict[str, str] = {
    "api_client_structure": "frontend",
    "cross_stack_field_usage": "frontend",
    "require_self_hosted_fonts": "frontend",
    "require_font_display_swap": "frontend",
    "require_router_ready_before_mount": "frontend",
    "require_lighthouse_scores": "frontend",
}


def _run_cross_file_linter(spec: LinterSpec) -> list[str]:
    """Run a cross-file linter that scans the appropriate directory."""
    module = importlib.import_module(f"blueprint_linters.{spec.module_name}")
    check_all = getattr(module, "check_all", None)
    if check_all is None:
        return []
    scan_path = Path(_LINTER_PATHS.get(spec.module_name, "backend"))
    return check_all(scan_path)


def main() -> None:
    """Entry point for the combined linter runner."""
    import argparse

    parser = argparse.ArgumentParser(description="Blueprint linter runner")
    parser.add_argument(
        "--preset",
        choices=list(PRESETS.keys()),
        required=True,
        help="Which preset to run (webapp or lib)",
    )
    parser.add_argument(
        "--push-only",
        action="store_true",
        help="Run only cross-file linters (for pre-push stage)",
    )
    parser.add_argument(
        "files",
        nargs="*",
        help="Files to check (ignored with --push-only)",
    )
    args = parser.parse_args()

    per_file_specs, cross_file_specs = PRESETS[args.preset]
    errors: list[str] = []

    if args.push_only:
        for spec in cross_file_specs:
            errors.extend(_run_cross_file_linter(spec))
    else:
        for spec in per_file_specs:
            errors.extend(_run_per_file_linter(spec, args.files))

    for error in errors:
        print(error)  # noqa: T201  # linter output
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
