#!/usr/bin/env python3
"""
Cross-stack linter: correlate backend response models with frontend field usage.

Parses three sources:
  1. Backend Pydantic models → response fields per endpoint
  2. Frontend api.ts → API functions with return types and interface fields
  3. Frontend Vue templates → which fields each component actually accesses

Reports:
  - Over-fetch: response fields no consuming component accesses
  - Under-fetch: component accesses a field the endpoint sends as default/empty
  - Dead fields: interface fields unused across ALL components
  - Dead endpoints: API functions never called by any component
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

# ---------------------------------------------------------------------------
# Phase 1: Parse api.ts → interfaces + API functions
# ---------------------------------------------------------------------------


@dataclass
class TsInterface:
    name: str
    fields: dict[str, str]  # {field_name: type_string}


@dataclass
class ApiFunction:
    name: str  # e.g. "decksApi.list"
    http_method: str  # get, post, patch, delete
    path: str  # "/decks" or "/decks/${id}"
    return_type: str  # "Deck[]" or "Deck" or ""


def parse_api_ts(api_ts_path: Path) -> tuple[dict[str, TsInterface], list[ApiFunction]]:
    """Parse api.ts to extract interfaces and API functions."""
    source = api_ts_path.read_text(encoding="utf-8")
    lines = source.splitlines()

    interfaces: dict[str, TsInterface] = {}
    api_functions: list[ApiFunction] = []

    # Parse interfaces
    current_interface: str | None = None
    current_fields: dict[str, str] = {}

    for line in lines:
        stripped = line.strip()

        # Single-line interface: export interface Foo { a: string; b: number }
        single_line_match = re.match(r"export\s+interface\s+(\w+)\s*\{(.+)\}", stripped)
        if single_line_match:
            name = single_line_match.group(1)
            body = single_line_match.group(2)
            fields: dict[str, str] = {}
            for field_part in body.split(";"):
                field_match = re.match(r"\s*(\w+)\s*\??\s*:\s*(.+)", field_part.strip())
                if field_match:
                    fields[field_match.group(1)] = field_match.group(2).strip()
            interfaces[name] = TsInterface(name=name, fields=fields)
            continue

        # Start of multi-line interface
        interface_match = re.match(r"export\s+interface\s+(\w+)\s*\{", stripped)
        if interface_match:
            current_interface = interface_match.group(1)
            current_fields = {}
            continue

        # End of multi-line interface
        if current_interface and stripped == "}":
            interfaces[current_interface] = TsInterface(name=current_interface, fields=current_fields)
            current_interface = None
            continue

        # Interface field
        if current_interface:
            field_match = re.match(r"(\w+)\s*\??\s*:\s*(.+?)(?:\s*$)", stripped)
            if field_match:
                current_fields[field_match.group(1)] = field_match.group(2).rstrip(",")

    # Parse API objects and their methods
    current_api_object: str | None = None

    for line in lines:
        stripped = line.strip()

        # Start of API object: export const decksApi = {
        api_obj_match = re.match(r"export\s+const\s+(\w+Api)\s*=\s*\{", stripped)
        if api_obj_match:
            current_api_object = api_obj_match.group(1)
            continue

        # End of API object
        if current_api_object and stripped == "}":
            current_api_object = None
            continue

        # API method: methodName: (...) => api.get<Type>('/path', ...)
        if current_api_object:
            method_match = re.match(
                r"(\w+)\s*:.*api\.(get|post|patch|put|delete)(?:<([^>]+)>)?\(\s*['\"`]([^'\"`]+)['\"`]",
                stripped,
            )
            if method_match:
                api_functions.append(
                    ApiFunction(
                        name=f"{current_api_object}.{method_match.group(1)}",
                        http_method=method_match.group(2),
                        path=method_match.group(4),
                        return_type=method_match.group(3) or "",
                    )
                )

    return interfaces, api_functions


# ---------------------------------------------------------------------------
# Phase 2: Parse Vue templates → field access per component
# ---------------------------------------------------------------------------


@dataclass
class ComponentUsage:
    filepath: Path
    api_calls: set[str] = field(default_factory=set)  # {"decksApi.list", "decksApi.get"}
    field_accesses: dict[str, set[str]] = field(default_factory=dict)  # {"deck": {"id", "name", ...}}


def parse_vue_component(vue_path: Path, known_api_objects: set[str]) -> ComponentUsage:
    """Parse a Vue SFC to find API calls and field accesses."""
    source = vue_path.read_text(encoding="utf-8")
    usage = ComponentUsage(filepath=vue_path)

    # Find API calls: decksApi.list(), eventsApi.get(id), etc.
    for match in re.finditer(r"(\w+Api)\.(\w+)\s*\(", source):
        api_obj = match.group(1)
        method = match.group(2)
        if api_obj in known_api_objects:
            usage.api_calls.add(f"{api_obj}.{method}")

    # Find dynamic API calls: const api = condition ? archetypesApi : opponentsApi; api.method()
    for assign_match in re.finditer(r"\b(?:const|let|var)\s+(\w+)\s*=\s*([^\n]+)", source):
        local_var = assign_match.group(1)
        assign_expr = assign_match.group(2)
        # Find all API objects in the assignment expression
        assigned_apis = {m.group(1) for m in re.finditer(r"(\w+Api)", assign_expr) if m.group(1) in known_api_objects}
        if not assigned_apis:
            continue
        # Find all method calls on the local var
        for call_match in re.finditer(rf"\b{re.escape(local_var)}\.(\w+)\s*\(", source):
            method = call_match.group(1)
            for api_obj in assigned_apis:
                usage.api_calls.add(f"{api_obj}.{method}")

    # Find field accesses in templates and script
    # Strategy: find v-for loop variables and track their field accesses
    # Pattern: v-for="item in items" → track item.field accesses
    loop_vars: dict[str, str] = {}  # {"deck": "decks", "event": "events"}

    for match in re.finditer(r'v-for="(\w+)\s+in\s+(\w+)"', source):
        loop_vars[match.group(1)] = match.group(2)

    # Track field accesses for loop variables and known data variables
    # Also track direct accesses like data.field, resp.json().field
    all_vars = set(loop_vars.keys())

    # Find reactive refs: const decks = ref<Deck[]>([])
    for match in re.finditer(r"const\s+(\w+)\s*=\s*(?:ref|computed)", source):
        all_vars.add(match.group(1))

    # Find destructured data: const { data: decks } = useStaleCache(...)
    for match in re.finditer(r"data:\s*(\w+)", source):
        all_vars.add(match.group(1))

    # Now find all field accesses: variable.field
    # Exclude API object names — their .method() calls are API calls, not field accesses
    _SKIP_FIELDS = {
        "value",
        "filter",
        "map",
        "reduce",
        "forEach",
        "find",
        "length",
        "push",
        "includes",
        "sort",
        "slice",
        "join",
        "trim",
        "toString",
        "padStart",
        "split",
        "replace",
        "json",
        "data",
        "headers",
        "then",
        "catch",
        "finally",
        "response",
    }

    for var_name in all_vars:
        if var_name in known_api_objects:
            continue
        fields: set[str] = set()
        for match in re.finditer(rf"\b{re.escape(var_name)}\.(\w+)", source):
            field_name = match.group(1)
            if field_name in _SKIP_FIELDS:
                continue
            fields.add(field_name)
        if fields:
            usage.field_accesses[var_name] = fields

    # Also catch Vue ref unwrapping: variable.value.field and variable.value?.field
    for var_name in all_vars:
        if var_name in known_api_objects:
            continue
        for match in re.finditer(rf"\b{re.escape(var_name)}\.value\??\.(\w+)", source):
            field_name = match.group(1)
            if field_name not in _SKIP_FIELDS:
                usage.field_accesses.setdefault(var_name, set()).add(field_name)

    # Catch destructured responses: const { data } = await api.get(...)
    # Then data.field accesses
    for match in re.finditer(r"\bdata\.(\w+)", source):
        field_name = match.group(1)
        if field_name not in _SKIP_FIELDS:
            usage.field_accesses.setdefault("__response__", set()).add(field_name)

    # Catch-all: collect ALL word.field patterns in the file as a global set
    # This overcounts (includes unrelated objects) but ensures zero false negatives
    all_fields_in_file: set[str] = set()
    for match in re.finditer(r"\b\w+\.(\w+)", source):
        field_name = match.group(1)
        if field_name not in _SKIP_FIELDS:
            all_fields_in_file.add(field_name)
    usage.field_accesses["__all__"] = all_fields_in_file

    # Also find field accesses in helper functions that take typed params
    # Pattern: function foo(e: Event): ... e.match_wins
    for match in re.finditer(r"function\s+\w+\((\w+):\s*(\w+)\)", source):
        param_name = match.group(1)
        if param_name not in usage.field_accesses:
            usage.field_accesses[param_name] = set()
        for field_match in re.finditer(rf"\b{re.escape(param_name)}\.(\w+)", source):
            usage.field_accesses[param_name].add(field_match.group(1))

    return usage


# ---------------------------------------------------------------------------
# Phase 3: Correlate and report
# ---------------------------------------------------------------------------


@dataclass
class Finding:
    severity: str  # "over-fetch", "under-fetch", "dead-field", "dead-endpoint"
    message: str


def _resolve_base_type(return_type: str) -> str:
    """Strip array notation: 'Deck[]' → 'Deck', 'Event[]' → 'Event'."""
    return return_type.replace("[]", "").strip()


def correlate(
    interfaces: dict[str, TsInterface],
    api_functions: list[ApiFunction],
    component_usages: list[ComponentUsage],
) -> list[Finding]:
    """Correlate backend types with frontend usage and report findings."""
    findings: list[Finding] = []

    # Build lookup: which components call which API functions
    func_to_components: dict[str, list[ComponentUsage]] = {}
    for func in api_functions:
        func_to_components[func.name] = []
    for usage in component_usages:
        for call in usage.api_calls:
            if call in func_to_components:
                func_to_components[call].append(usage)

    # Dead endpoint detection
    findings.extend(
        Finding(
            severity="dead-endpoint",
            message=f"API function {func.name} ({func.http_method.upper()} {func.path}) "
            f"is never called by any Vue component",
        )
        for func in api_functions
        if not func_to_components.get(func.name)
    )

    # Per-function over-fetch / under-fetch detection
    for func in api_functions:
        if not func.return_type:
            continue

        base_type = _resolve_base_type(func.return_type)
        interface = interfaces.get(base_type)
        if interface is None:
            continue

        consumers = func_to_components.get(func.name, [])
        if not consumers:
            continue

        # Collect all fields accessed across all consuming components
        all_accessed_fields: set[str] = set()
        for usage in consumers:
            for fields in usage.field_accesses.values():
                all_accessed_fields |= fields

        # Over-fetch: interface fields not accessed by any consumer
        interface_fields = set(interface.fields.keys())
        unused = interface_fields - all_accessed_fields
        # Filter out common framework fields that are accessed indirectly
        unused -= {"id"}  # id is often used as :key in v-for but matched via loop var
        if unused:
            consumer_names = ", ".join(u.filepath.name for u in consumers)
            findings.append(
                Finding(
                    severity="over-fetch",
                    message=f"{func.name} → {base_type}: fields not used by any consumer "
                    f"({consumer_names}): {', '.join(sorted(unused))}",
                )
            )

    return findings


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def check_all(frontend_path: Path) -> list[str]:
    """
    Run the cross-stack linter on the frontend directory.
    Returns error messages (empty list = clean).
    """
    api_ts = frontend_path / "src" / "api.ts"
    if not api_ts.exists():
        api_ts = frontend_path / "src" / "api" / "index.ts"
    if not api_ts.exists():
        return []  # No frontend API client — nothing to check

    interfaces, api_functions = parse_api_ts(api_ts)
    if not api_functions:
        return []

    known_api_objects = {f.name.split(".")[0] for f in api_functions}
    component_usages: list[ComponentUsage] = []
    for vue_dir_name in ("views", "components"):
        vue_dir = frontend_path / "src" / vue_dir_name
        if not vue_dir.exists():
            continue
        for vue_file in sorted(vue_dir.glob("*.vue")):
            usage = parse_vue_component(vue_file, known_api_objects)
            if usage.api_calls:
                component_usages.append(usage)

    findings = correlate(interfaces, api_functions, component_usages)
    return [f"[{f.severity}] {f.message}" for f in sorted(findings, key=lambda f: (f.severity, f.message))]


def main() -> None:
    frontend = Path("frontend")
    if len(sys.argv) > 1:
        frontend = Path(sys.argv[1])
    errors = check_all(frontend)
    for error in errors:
        print(error)  # noqa: T201  # linter diagnostic output
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
