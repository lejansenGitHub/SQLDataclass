"""Tests for the minimal exports linter."""

from __future__ import annotations

import tempfile
from pathlib import Path

from blueprint_linters.minimal_exports import check_all


def _setup(tmp: str, files: dict[str, str]) -> Path:
    """Create files in a temp directory structure."""
    root = Path(tmp)
    for path, content in files.items():
        full = root / path
        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_text(content, encoding="utf-8")
    return root / "backend"


def test_used_export_passes() -> None:
    """An exported symbol that is imported by another module passes."""
    with tempfile.TemporaryDirectory() as tmp:
        backend = _setup(tmp, {
            "backend/service/orders/exports/services/order_service.py": "class OrderService: pass\n",
            "backend/app/api/src/endpoints.py": "from backend.service.orders.exports.services.order_service import OrderService\n",
        })
        errors = check_all(backend)
        assert errors == []


def test_unused_export_rejected() -> None:
    """An exported symbol that nobody imports is dead coupling surface."""
    with tempfile.TemporaryDirectory() as tmp:
        backend = _setup(tmp, {
            "backend/service/orders/exports/services/order_service.py": "class OrderService: pass\n",
            "backend/app/api/src/endpoints.py": "x = 1\n",
        })
        errors = check_all(backend)
        assert len(errors) == 1
        assert "OrderService" in errors[0]
        assert "not imported" in errors[0]


def test_init_files_skipped() -> None:
    """__init__.py in exports/ is not checked (it's just re-exports)."""
    with tempfile.TemporaryDirectory() as tmp:
        backend = _setup(tmp, {
            "backend/service/orders/exports/__init__.py": "from .services.order_service import OrderService\n",
            "backend/service/orders/exports/services/order_service.py": "class OrderService: pass\n",
            "backend/app/api/src/endpoints.py": "from backend.service.orders.exports.services.order_service import OrderService\n",
        })
        errors = check_all(backend)
        assert errors == []


def test_private_names_skipped() -> None:
    """Names starting with _ are private and not checked."""
    with tempfile.TemporaryDirectory() as tmp:
        backend = _setup(tmp, {
            "backend/service/orders/exports/services/helpers.py": "_internal = 42\npublic_fn = lambda: None\n",
            "backend/app/api/src/endpoints.py": "from backend.service.orders.exports.services.helpers import public_fn\n",
        })
        errors = check_all(backend)
        assert errors == []


def test_no_exports_returns_empty() -> None:
    """If no exports/ directories exist, no errors."""
    with tempfile.TemporaryDirectory() as tmp:
        backend = _setup(tmp, {
            "backend/service/orders/src/repo.py": "class OrderRepo: pass\n",
        })
        errors = check_all(backend)
        assert errors == []
