"""Tests for the cross-stack field usage linter."""

from __future__ import annotations

import tempfile
from pathlib import Path

from blueprint_linters.cross_stack_field_usage import (
    ApiFunction,
    ComponentUsage,
    TsInterface,
    correlate,
    parse_api_ts,
    parse_vue_component,
)


def _write_file(directory: Path, name: str, content: str) -> Path:
    path = directory / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


# --- api.ts parsing ---


def test_parse_multiline_interface() -> None:
    """Multi-line interfaces are parsed into name → fields mapping."""
    with tempfile.TemporaryDirectory() as tmp:
        _write_file(Path(tmp), "api.ts", """
export interface Deck {
  id: number
  name: string
  cards: DeckCard[]
}
""")
        interfaces, _ = parse_api_ts(Path(tmp) / "api.ts")
        assert "Deck" in interfaces
        assert interfaces["Deck"].fields == {"id": "number", "name": "string", "cards": "DeckCard[]"}


def test_parse_single_line_interface() -> None:
    """Single-line interfaces (e.g. MergeResult) are also parsed."""
    with tempfile.TemporaryDirectory() as tmp:
        _write_file(Path(tmp), "api.ts", """
export interface MergeResult { merged: string; into: string }
""")
        interfaces, _ = parse_api_ts(Path(tmp) / "api.ts")
        assert "MergeResult" in interfaces
        assert interfaces["MergeResult"].fields == {"merged": "string", "into": "string"}


def test_parse_api_functions() -> None:
    """API functions are extracted with method, path, and return type."""
    with tempfile.TemporaryDirectory() as tmp:
        _write_file(Path(tmp), "api.ts", """
export const decksApi = {
  list: () => api.get<Deck[]>('/decks'),
  get: (id: number) => api.get<Deck>(`/decks/${id}`),
  delete: (id: number) => api.delete(`/decks/${id}`),
}
""")
        _, funcs = parse_api_ts(Path(tmp) / "api.ts")
        assert len(funcs) == 3
        list_func = next(f for f in funcs if f.name == "decksApi.list")
        assert list_func.return_type == "Deck[]"
        assert list_func.path == "/decks"
        delete_func = next(f for f in funcs if f.name == "decksApi.delete")
        assert delete_func.return_type == ""


# --- Vue component parsing ---


def test_parse_vue_api_calls() -> None:
    """API calls in Vue components are detected."""
    with tempfile.TemporaryDirectory() as tmp:
        path = _write_file(Path(tmp), "ListView.vue", """
<script setup lang="ts">
import { decksApi } from '@/api'
const decks = ref([])
async function load() {
  const { data } = await decksApi.list()
  decks.value = data
}
</script>
<template><div v-for="d in decks" :key="d.id">{{ d.name }}</div></template>
""")
        usage = parse_vue_component(path, {"decksApi"})
        assert "decksApi.list" in usage.api_calls


def test_parse_vue_field_accesses() -> None:
    """Field accesses on loop variables and refs are tracked."""
    with tempfile.TemporaryDirectory() as tmp:
        path = _write_file(Path(tmp), "ListView.vue", """
<script setup lang="ts">
const decks = ref([])
</script>
<template>
<div v-for="deck in decks" :key="deck.id">
  {{ deck.name }} {{ deck.status }}
</div>
</template>
""")
        usage = parse_vue_component(path, set())
        # deck fields found via catch-all scanner
        all_fields = usage.field_accesses.get("__all__", set())
        assert "name" in all_fields
        assert "status" in all_fields


def test_parse_vue_ref_value_optional_chaining() -> None:
    """deck.value?.field accesses are tracked (Vue ref unwrapping in script)."""
    with tempfile.TemporaryDirectory() as tmp:
        path = _write_file(Path(tmp), "DetailView.vue", """
<script setup lang="ts">
const deck = ref(null)
const name = computed(() => deck.value?.name ?? '')
const arch = computed(() => deck.value?.archetype ?? '')
</script>
<template><div>{{ deck.name }}</div></template>
""")
        usage = parse_vue_component(path, set())
        deck_fields = usage.field_accesses.get("deck", set())
        assert "name" in deck_fields
        assert "archetype" in deck_fields


# --- Correlation ---


def test_over_fetch_detection() -> None:
    """Fields in the interface but not accessed by any consumer are over-fetched."""
    interfaces = {
        "Deck": TsInterface(name="Deck", fields={"id": "number", "name": "string", "created_at": "string"}),
    }
    api_functions = [
        ApiFunction(name="decksApi.list", http_method="get", path="/decks", return_type="Deck[]"),
    ]
    component_usages = [
        ComponentUsage(
            filepath=Path("DeckList.vue"),
            api_calls={"decksApi.list"},
            field_accesses={"deck": {"name"}, "__all__": {"id", "name"}},
        ),
    ]

    findings = correlate(interfaces, api_functions, component_usages)
    over_fetch = [f for f in findings if f.severity == "over-fetch"]
    assert len(over_fetch) == 1
    assert "created_at" in over_fetch[0].message


def test_dead_endpoint_detection() -> None:
    """API functions not called by any component are dead endpoints."""
    interfaces = {"Deck": TsInterface(name="Deck", fields={"id": "number"})}
    api_functions = [
        ApiFunction(name="decksApi.list", http_method="get", path="/decks", return_type="Deck[]"),
        ApiFunction(name="decksApi.unused", http_method="get", path="/decks/unused", return_type="Deck"),
    ]
    component_usages = [
        ComponentUsage(filepath=Path("DeckList.vue"), api_calls={"decksApi.list"}, field_accesses={}),
    ]

    findings = correlate(interfaces, api_functions, component_usages)
    dead = [f for f in findings if f.severity == "dead-endpoint"]
    assert len(dead) == 1
    assert "decksApi.unused" in dead[0].message


def test_all_fields_used_no_findings() -> None:
    """When all fields are accessed, no over-fetch is reported."""
    interfaces = {
        "Deck": TsInterface(name="Deck", fields={"id": "number", "name": "string"}),
    }
    api_functions = [
        ApiFunction(name="decksApi.list", http_method="get", path="/decks", return_type="Deck[]"),
    ]
    component_usages = [
        ComponentUsage(
            filepath=Path("DeckList.vue"),
            api_calls={"decksApi.list"},
            field_accesses={"__all__": {"id", "name"}},
        ),
    ]

    findings = correlate(interfaces, api_functions, component_usages)
    assert findings == []


def test_no_frontend_returns_empty() -> None:
    """If no frontend directory exists, the linter returns no errors."""
    from blueprint_linters.cross_stack_field_usage import check_all
    errors = check_all(Path("/nonexistent/frontend"))
    assert errors == []
