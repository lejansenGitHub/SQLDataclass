"""Tests for the API client structure linter."""

from __future__ import annotations

import tempfile
from pathlib import Path

from blueprint_linters.api_client_structure import check_api_client


def _write_ts(content: str) -> Path:
    """Write a temporary .ts file and return its path."""
    path = Path(tempfile.mktemp(suffix=".ts"))
    path.write_text(content, encoding="utf-8")
    return path


def test_typed_api_call_passes() -> None:
    """
    API calls with explicit type parameters satisfy the structure requirement.
    """
    source = "  list: () => api.get<Deck[]>('/decks'),\n"
    path = _write_ts(source)
    assert check_api_client(path) == []
    path.unlink()


def test_untyped_api_call_rejected() -> None:
    """
    API calls without type parameters can't be parsed by cross-stack linters —
    there's no way to know what interface the response maps to.
    """
    source = "  list: () => api.get('/decks'),\n"
    path = _write_ts(source)
    errors = check_api_client(path)
    assert len(errors) == 1
    assert "return type" in errors[0]
    path.unlink()


def test_template_literal_path_passes() -> None:
    """
    Template literal paths (backtick strings with ${}) are valid string literals.
    """
    source = "  get: (id: number) => api.get<Deck>(`/decks/${id}`),\n"
    path = _write_ts(source)
    assert check_api_client(path) == []
    path.unlink()


def test_any_type_in_interface_rejected() -> None:
    """
    'any' in interface fields defeats type safety and makes cross-stack
    correlation impossible.
    """
    source = "  data: any\n"
    path = _write_ts(source)
    errors = check_api_client(path)
    assert len(errors) == 1
    assert "'any'" in errors[0]
    path.unlink()


def test_explicit_type_in_interface_passes() -> None:
    """
    Explicit types in interface fields are fine.
    """
    source = "  name: string\n  count: number\n"
    path = _write_ts(source)
    assert check_api_client(path) == []
    path.unlink()


def test_non_ts_file_ignored() -> None:
    """
    Non-TypeScript files are skipped entirely.
    """
    path = Path(tempfile.mktemp(suffix=".py"))
    path.write_text("api.get('/foo')", encoding="utf-8")
    assert check_api_client(path) == []
    path.unlink()


def test_delete_without_type_allowed() -> None:
    """
    DELETE calls don't return data (204 No Content) — they're exempt from
    the return type requirement since there are no response fields to correlate.
    """
    source = "  delete: (id: number) => api.delete(`/decks/${id}`),\n"
    path = _write_ts(source)
    errors = check_api_client(path)
    assert errors == []
    path.unlink()


def test_post_without_type_rejected() -> None:
    """
    POST calls that return data must have an explicit type — the response
    has fields that cross-stack linters need to correlate.
    """
    source = "  merge: (sid: number, tid: number) => api.post('/merge', { source_id: sid }),\n"
    path = _write_ts(source)
    errors = check_api_client(path)
    assert len(errors) == 1
    assert "return type" in errors[0]
    path.unlink()


def test_full_api_client_passes() -> None:
    """
    A realistic api.ts file with interfaces and typed API calls passes all checks.
    """
    source = """
export interface Deck {
  id: number
  name: string
  cards: DeckCard[]
  status: 'draft' | 'complete'
}

export interface DeckCard {
  id: number
  card_name: string
  quantity: number
}

export const decksApi = {
  list: () => api.get<Deck[]>('/decks'),
  get: (id: number) => api.get<Deck>(`/decks/${id}`),
  create: (data: { name: string }) => api.post<Deck>('/decks', data),
}
"""
    path = _write_ts(source)
    assert check_api_client(path) == []
    path.unlink()
