"""Tests for the write endpoint persistence test linter."""

from __future__ import annotations

import tempfile
from pathlib import Path

from blueprint_linters.write_endpoint_persist_test import check_all


def _write_file(directory: Path, name: str, content: str) -> Path:
    path = directory / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


_URLS_PY = """\
API_PREFIX = "/api"
THINGS = API_PREFIX + "/things"
THING = API_PREFIX + "/things/{thing_id}"
AUTH_LOGIN = API_PREFIX + "/auth/login"
"""

_ENDPOINT_WITH_WRITE_REPO = """\
from urls import THINGS, THING

@router.get(THINGS)
def list_things():
    pass

@router.patch(THING)
def update_thing(thing_id: int, write_repo: ThingWriteRepository = Depends()):
    pass
"""

_ENDPOINT_WITHOUT_WRITE_REPO = """\
from urls import AUTH_LOGIN

@router.post(AUTH_LOGIN)
def login(read_repo: UserReadRepository = Depends()):
    pass
"""

_TEST_WITH_PERSIST = """\
from backend.app.api.src.urls import THINGS, THING

def test_update_thing(client):
    resp = client.patch(THING.format(thing_id=1), json={"name": "new"})
    assert resp.status_code == 200
    names = {t["name"] for t in client.get(THINGS).json()}
    assert "new" in names
"""

_TEST_WITHOUT_PERSIST = """\
from backend.app.api.src.urls import THING

def test_update_thing(client):
    resp = client.patch(THING.format(thing_id=1), json={"name": "new"})
    assert resp.status_code == 200
    assert resp.json()["name"] == "new"
"""


def test_write_endpoint_with_persist_test_passes() -> None:
    """
    A write endpoint whose test re-fetches via .get() passes the check.
    """
    with tempfile.TemporaryDirectory() as tmp:
        backend = Path(tmp) / "backend"
        _write_file(backend, "app/api/src/urls.py", _URLS_PY)
        _write_file(backend, "app/api/src/thing_endpoints.py", _ENDPOINT_WITH_WRITE_REPO)
        _write_file(backend, "app/api/tests/integration_tests/test_thing.py", _TEST_WITH_PERSIST)

        errors = check_all(backend)
        assert errors == []


def test_write_endpoint_without_persist_test_rejected() -> None:
    """
    A write endpoint whose test only checks the response (no .get()
    re-fetch) is flagged because the test would pass even if the
    transaction was silently rolled back.
    """
    with tempfile.TemporaryDirectory() as tmp:
        backend = Path(tmp) / "backend"
        _write_file(backend, "app/api/src/urls.py", _URLS_PY)
        _write_file(backend, "app/api/src/thing_endpoints.py", _ENDPOINT_WITH_WRITE_REPO)
        _write_file(backend, "app/api/tests/integration_tests/test_thing.py", _TEST_WITHOUT_PERSIST)

        errors = check_all(backend)
        assert len(errors) == 1
        assert "THING" in errors[0]
        assert "persistence test" in errors[0]


def test_get_endpoint_not_flagged() -> None:
    """
    GET endpoints are read-only and don't need persistence tests.
    """
    with tempfile.TemporaryDirectory() as tmp:
        backend = Path(tmp) / "backend"
        _write_file(backend, "app/api/src/urls.py", _URLS_PY)
        _write_file(backend, "app/api/src/thing_endpoints.py", """\
from urls import THINGS

@router.get(THINGS)
def list_things():
    pass
""")
        errors = check_all(backend)
        assert errors == []


def test_post_without_write_repo_not_flagged() -> None:
    """
    POST endpoints that don't inject a WriteRepository (e.g. login,
    preview) are read-only and don't need persistence tests.
    """
    with tempfile.TemporaryDirectory() as tmp:
        backend = Path(tmp) / "backend"
        _write_file(backend, "app/api/src/urls.py", _URLS_PY)
        _write_file(backend, "app/api/src/auth_endpoints.py", _ENDPOINT_WITHOUT_WRITE_REPO)

        errors = check_all(backend)
        assert errors == []


def test_multiple_tests_one_with_persist_passes() -> None:
    """
    Only one test per write endpoint needs the persistence check.
    Error-case tests (404, 409) don't need it.
    """
    with tempfile.TemporaryDirectory() as tmp:
        backend = Path(tmp) / "backend"
        _write_file(backend, "app/api/src/urls.py", _URLS_PY)
        _write_file(backend, "app/api/src/thing_endpoints.py", _ENDPOINT_WITH_WRITE_REPO)
        _write_file(backend, "app/api/tests/integration_tests/test_thing.py", """\
from backend.app.api.src.urls import THINGS, THING

def test_update_thing_not_found(client):
    resp = client.patch(THING.format(thing_id=999), json={"name": "new"})
    assert resp.status_code == 404

def test_update_thing(client):
    resp = client.patch(THING.format(thing_id=1), json={"name": "new"})
    assert resp.status_code == 200
    names = {t["name"] for t in client.get(THINGS).json()}
    assert "new" in names
""")
        errors = check_all(backend)
        assert errors == []


def test_delete_endpoint_with_write_repo_needs_persist_test() -> None:
    """DELETE endpoints with a write repo also need a persistence check."""
    with tempfile.TemporaryDirectory() as tmp:
        backend = Path(tmp) / "backend"
        _write_file(backend, "app/api/src/urls.py", _URLS_PY)
        _write_file(backend, "app/api/src/thing_endpoints.py", """\
from urls import THING

@router.delete(THING)
def delete_thing(thing_id: int, write_repo: ThingWriteRepository = Depends()):
    pass
""")
        _write_file(backend, "app/api/tests/integration_tests/test_thing.py", """\
from backend.app.api.src.urls import THING

def test_delete_thing(client):
    resp = client.delete(THING.format(thing_id=1))
    assert resp.status_code == 204
""")
        errors = check_all(backend)
        assert len(errors) == 1
        assert "THING" in errors[0]


def test_helper_functions_resolved_for_write_and_get() -> None:
    """
    Write calls in helpers (e.g. _create_thing) and get calls in helpers
    (e.g. _get_thing_names) are resolved one level deep so common test
    patterns like _create + _get_ids pass the check.
    """
    with tempfile.TemporaryDirectory() as tmp:
        backend = Path(tmp) / "backend"
        _write_file(backend, "app/api/src/urls.py", _URLS_PY)
        _write_file(backend, "app/api/src/thing_endpoints.py", """\
from urls import THINGS

@router.get(THINGS)
def list_things():
    pass

@router.post(THINGS)
def create_thing(write_repo: ThingWriteRepository = Depends()):
    pass
""")
        _write_file(backend, "app/api/tests/integration_tests/test_thing.py", """\
from backend.app.api.src.urls import THINGS

def _create_thing(client, name):
    resp = client.post(THINGS, json={"name": name})
    assert resp.status_code == 201
    return resp.json()

def _get_thing_names(client):
    return {t["name"] for t in client.get(THINGS).json()}

def test_create_thing(client):
    _create_thing(client, "Widget")
    names = _get_thing_names(client)
    assert "Widget" in names
""")
        errors = check_all(backend)
        assert errors == []


def test_delete_endpoint_without_write_repo_not_flagged() -> None:
    """DELETE endpoints without a write repo are not flagged."""
    with tempfile.TemporaryDirectory() as tmp:
        backend = Path(tmp) / "backend"
        _write_file(backend, "app/api/src/urls.py", _URLS_PY)
        _write_file(backend, "app/api/src/thing_endpoints.py", """\
from urls import THING

@router.delete(THING)
def delete_thing(thing_id: int):
    pass
""")
        errors = check_all(backend)
        assert errors == []
